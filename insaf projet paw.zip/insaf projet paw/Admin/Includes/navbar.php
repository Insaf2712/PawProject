<?php 
  $query = "SELECT * FROM tbladmin WHERE Id = ".$_SESSION['userId']."";
  $rs = $conn->query($query);
  $num = $rs->num_rows;
  $rows = $rs->fetch_assoc();
  $fullName = $rows['firstName']." ".$rows['lastName'];
?>
<nav class="navbar navbar-expand-lg navbar-modern">
  <div class="container-fluid">
    <!-- Brand/Logo -->
    <a class="navbar-brand" href="index.php">
      <img src="img/logo/attnlg.jpg" alt="Univ Alger 1" class="navbar-logo">
      <span class="navbar-brand-text">Univ Alger 1 - Info</span>
    </a>
    
    <!-- Toggle button for mobile -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon">
        <i class="fas fa-bars"></i>
      </span>
    </button>

    <!-- Navbar content -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <!-- Navigation Links -->
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        
        <!-- Class and Class Arms Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="classesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-chalkboard"></i>
            <span>Classes</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="classesDropdown">
            <h6 class="dropdown-header">Manage Classes</h6>
            <a class="dropdown-item" href="createClass.php">
              <i class="fas fa-chalkboard mr-2"></i>Create Class
            </a>
            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">Manage Class Arms</h6>
            <a class="dropdown-item" href="createClassArms.php">
              <i class="fas fa-code-branch mr-2"></i>Create Class Arms
            </a>
          </div>
        </li>

        <!-- Teachers Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="teachersDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teachers</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="teachersDropdown">
            <h6 class="dropdown-header">Manage Class Teachers</h6>
            <a class="dropdown-item" href="createClassTeacher.php">
              <i class="fas fa-chalkboard-teacher mr-2"></i>Create Class Teachers
            </a>
          </div>
        </li>

        <!-- Students Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="studentsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="studentsDropdown">
            <h6 class="dropdown-header">Manage Students</h6>
            <a class="dropdown-item" href="createStudents.php">
              <i class="fas fa-user-graduate mr-2"></i>Create Students
            </a>
          </div>
        </li>

        <!-- Session & Term Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="sessionDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-calendar-alt"></i>
            <span>Session & Term</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="sessionDropdown">
            <h6 class="dropdown-header">Manage Session & Term</h6>
            <a class="dropdown-item" href="createSessionTerm.php">
              <i class="fa fa-calendar-alt mr-2"></i>Create Session and Term
            </a>
          </div>
        </li>
      </ul>

      <!-- Right side: Search and User -->
      <ul class="navbar-nav ml-auto">
        <!-- Search -->
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-search"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right p-3 search-dropdown" aria-labelledby="searchDropdown">
            <form class="navbar-search">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="What do you want to look for?" aria-label="Search">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="button">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        <!-- User Profile -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle user-profile-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class="img-profile rounded-circle" src="img/user-icn.png" alt="Profile">
            <span class="ml-2 d-none d-lg-inline"><b>Welcome <?php echo $fullName;?></b></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logout.php">
              <i class="fas fa-power-off fa-fw mr-2 text-danger"></i>
              Logout
            </a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

