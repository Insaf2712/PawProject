<?php 
  $query = "SELECT * FROM tblclassteacher WHERE Id = ".$_SESSION['userId']."";
  $rs = $conn->query($query);
  $num = $rs->num_rows;
  $rows = $rs->fetch_assoc();
  $fullName = $rows['firstName']." ".$rows['lastName'];
?>
<nav class="navbar navbar-expand-lg navbar-modern">
  <div class="container-fluid">
    <!-- Brand/Logo -->
    <a class="navbar-brand" href="index.php">
      <img src="img/logo/attnlg.jpg" alt="Univ Alger 1" class="navbar-logo">
      <span class="navbar-brand-text">Univ Alger 1 - Info</span>
    </a>
    
    <!-- Toggle button for mobile -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon">
        <i class="fas fa-bars"></i>
      </span>
    </button>

    <!-- Navbar content -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <!-- Navigation Links -->
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        
        <!-- Students Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="studentsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="studentsDropdown">
            <h6 class="dropdown-header">Manage Students</h6>
            <a class="dropdown-item" href="viewStudents.php">
              <i class="fas fa-user-graduate mr-2"></i>View Students
            </a>
          </div>
        </li>

        <!-- Attendance Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="attendanceDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-calendar-alt"></i>
            <span>Attendance</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="attendanceDropdown">
            <h6 class="dropdown-header">Manage Attendance</h6>
            <a class="dropdown-item" href="takeAttendance.php">
              <i class="fa fa-calendar-check mr-2"></i>Take Attendance
            </a>
            <a class="dropdown-item" href="viewAttendance.php">
              <i class="fa fa-calendar mr-2"></i>View Class Attendance
            </a>
            <a class="dropdown-item" href="viewStudentAttendance.php">
              <i class="fa fa-user-check mr-2"></i>View Student Attendance
            </a>
            <a class="dropdown-item" href="downloadRecord.php">
              <i class="fa fa-file-excel mr-2"></i>Today's Report (xls)
            </a>
          </div>
        </li>
      </ul>

      <!-- Right side: Search and User -->
      <ul class="navbar-nav ml-auto">
        <!-- Search -->
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-search"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right p-3 search-dropdown" aria-labelledby="searchDropdown">
            <form class="navbar-search">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="What do you want to look for?" aria-label="Search">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="button">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        <!-- User Profile -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle user-profile-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class="img-profile rounded-circle" src="img/user-icn.png" alt="Profile">
            <span class="ml-2 d-none d-lg-inline"><b>Welcome <?php echo $fullName;?></b></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logout.php">
              <i class="fas fa-power-off fa-fw mr-2 text-danger"></i>
              Logout
            </a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

