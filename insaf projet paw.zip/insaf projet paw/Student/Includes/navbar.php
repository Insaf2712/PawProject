<?php 
  $studentQuery = "SELECT firstName,lastName FROM tblstudents WHERE Id = ".$_SESSION['studentId']."";
  $rsStudent = $conn->query($studentQuery);
  $student = $rsStudent->fetch_assoc();
  $fullName = $student ? $student['firstName']." ".$student['lastName'] : "Etudiant";
?>
<nav class="navbar navbar-expand-lg navbar-modern">
  <div class="container-fluid">
    <!-- Brand/Logo -->
    <a class="navbar-brand" href="index.php">
      <img src="../img/logo/attnlg.jpg" alt="Univ Alger 1" class="navbar-logo">
      <span class="navbar-brand-text">Univ Alger 1 - Info</span>
    </a>
    
    <!-- Toggle button for mobile -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon">
        <i class="fas fa-bars"></i>
      </span>
    </button>

    <!-- Navbar content -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <!-- Navigation Links -->
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-home"></i>
            <span>Accueil</span>
          </a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="attendance.php">
            <i class="fa fa-calendar-check"></i>
            <span>Mes présences</span>
          </a>
        </li>
      </ul>

      <!-- Right side: User -->
      <ul class="navbar-nav ml-auto">
        <!-- User Profile -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle user-profile-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class="img-profile rounded-circle" src="../img/user-icn.png" alt="Profile">
            <span class="ml-2 d-none d-lg-inline"><b><?php echo $fullName;?></b></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logout.php">
              <i class="fas fa-power-off fa-fw mr-2 text-danger"></i>
              Se déconnecter
            </a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

