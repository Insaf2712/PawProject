<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
     <a class="sidebar-brand d-flex align-items-center bg-gradient-primary justify-content-center" href="index.php">
       <div class="sidebar-brand-icon">
         <img src="../img/logo/attnlg.jpg">
       </div>
       <div class="sidebar-brand-text mx-3">AMS</div>
     </a>
     <hr class="sidebar-divider my-0">
     <li class="nav-item active">
       <a class="nav-link" href="index.php">
         <i class="fas fa-fw fa-home"></i>
         <span>Accueil</span></a>
     </li>
     <hr class="sidebar-divider">
     <div class="sidebar-heading">
       Présence
     </div>
     <li class="nav-item">
       <a class="nav-link" href="attendance.php">
         <i class="fa fa-calendar-check"></i>
         <span>Mes présences</span>
       </a>
     </li>
     <hr class="sidebar-divider">
</ul>

